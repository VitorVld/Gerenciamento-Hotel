module gerenciamentohotel {
}