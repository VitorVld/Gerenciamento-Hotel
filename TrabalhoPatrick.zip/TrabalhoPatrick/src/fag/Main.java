package fag;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Hotel hotel = new Hotel();
        Scanner scanner = new Scanner(System.in);
        int comando;

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        System.out.println("Gerenciador de Hotel");
        System.out.println("1. Cadastrar Quarto");
        System.out.println("2. Listar Quartos");
        System.out.println("3. Reservar Quarto");
        System.out.println("4. Check-in");
        System.out.println("5. Check-out");
        System.out.println("6. Relatório de Ocupação");
        System.out.println("7. Relatório de Histórico");
        System.out.println("0. Sair");

        while (true) {
            System.out.print("Digite um comando (número): ");
            comando = scanner.nextInt();

            switch (comando) {
                case 1:
                    System.out.print("Número do quarto: ");
                    int numero = scanner.nextInt();
                    System.out.print("Tipo de quarto (solteiro, casal, suite): ");
                    String tipo = scanner.next();
                    System.out.print("Preço diário: ");
                    double preco = scanner.nextDouble();
                    hotel.cadastrarQuarto(numero, tipo, preco);
                    break;
                case 2:
                    hotel.listarQuartos();
                    break;
                case 3:
                    System.out.print("Nome do hóspede: ");
                    scanner.nextLine();
                    String nomeHospede = scanner.nextLine();
                    System.out.print("Data de check-in (DD/MM/YYYY): ");
                    LocalDate checkIn = LocalDate.parse(scanner.nextLine(), formatter);
                    System.out.print("Data de check-out (DD/MM/YYYY): ");
                    LocalDate checkOut = LocalDate.parse(scanner.nextLine(), formatter);
                    System.out.print("Número de quartos: ");
                    int numeroQuartos = scanner.nextInt();
                    System.out.print("Tipo de quarto: ");
                    String tipoQuarto = scanner.next();
                    hotel.reservarQuarto(nomeHospede, checkIn, checkOut, numeroQuartos, tipoQuarto);
                    break;
                case 4:
                    System.out.print("Nome do hóspede: ");
                    scanner.nextLine();
                    String nomeCheckIn = scanner.nextLine();
                    hotel.checkIn(nomeCheckIn);
                    break;
                case 5:
                    System.out.print("Nome do hóspede: ");
                    scanner.nextLine();
                    String nomeCheckOut = scanner.nextLine();
                    hotel.checkOut(nomeCheckOut);
                    break;
                case 6:
                    hotel.relatorioOcupacao();
                    break;
                case 7:
                    hotel.relatorioHistoricoReservas();
                    break;
                case 0:
                    System.out.println("Saindo...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Comando inválido. Tente novamente.");
            }
        }
    }
}
