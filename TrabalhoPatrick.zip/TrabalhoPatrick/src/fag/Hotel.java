package fag;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Hotel {
    private List<Quarto> quartos;
    private List<Reserva> reservas;

    public Hotel() {
        quartos = new ArrayList<>();
        reservas = new ArrayList<>();
    }

    public void cadastrarQuarto(int numero, String tipo, double precoDiario) {
        quartos.add(new Quarto(numero, tipo, precoDiario));
    }

    public void listarQuartos() {
        for (Quarto quarto : quartos) {
            System.out.println(quarto);
        }
    }

    public void reservarQuarto(String nomeHospede, LocalDate dataCheckIn, LocalDate dataCheckOut, int numeroQuartos, String tipoQuarto) {
        for (Quarto quarto : quartos) {
            if (quarto.isDisponivel() && quarto.getTipo().equals(tipoQuarto)) {
                reservas.add(new Reserva(nomeHospede, dataCheckIn, dataCheckOut, numeroQuartos, tipoQuarto));
                quarto.setDisponivel(false);
                System.out.println("Reserva realizada: " + nomeHospede);
                return;
            }
        }
        System.out.println("Nenhum quarto disponível do tipo " + tipoQuarto);
    }

    public void checkIn(String nomeHospede) {
        for (Reserva reserva : reservas) {
            if (reserva.getNomeHospede().equals(nomeHospede)) {
                System.out.println("Check-in realizado para " + nomeHospede);
                return;
            }
        }
        System.out.println("Nenhuma reserva encontrada para " + nomeHospede);
    }

    public void checkOut(String nomeHospede) {
        for (Reserva reserva : reservas) {
            if (reserva.getNomeHospede().equals(nomeHospede)) {
                for (Quarto quarto : quartos) {
                    if (!quarto.isDisponivel()) {
                        quarto.setDisponivel(true);
                    }
                }
                System.out.println("Check-out realizado para " + nomeHospede);
                return;
            }
        }
        System.out.println("Nenhuma reserva encontrada para " + nomeHospede);
    }

    public void relatorioOcupacao() {
        int quartosOcupados = 0;
        for (Quarto quarto : quartos) {
            if (!quarto.isDisponivel()) {
                quartosOcupados++;
            }
        }
        System.out.println("Total de quartos ocupados: " + quartosOcupados);
    }

    public void relatorioHistoricoReservas() {
        for (Reserva reserva : reservas) {
            System.out.println(reserva);
        }
    }
}
